class SVGSizeError(Exception):

    def __init__(self, *args, **kwargs):
        pass
