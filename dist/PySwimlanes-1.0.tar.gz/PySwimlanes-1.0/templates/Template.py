class Template:

    def __int__(self):
        pass