class DiagramItem:

    def __int__(self):
        pass
